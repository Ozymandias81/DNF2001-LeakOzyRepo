Fun little particle fix, proof of concept for @thatdarnowl and @Programmer maybe?  Replace in your system folder (note, if you play online/multiplayer, this will cause a mismatch trying to join servers for now, so make backups)

Fixes:

-Adds alpha fade out to Flame Thrower primary fire effect, trails off a lot more smoothly now
-Adds subtle quick fade out for most of the large sparks effects (lightning strike on rooftops for example) so they don't just vanish instantly, but I kept it very quick to replicate a hot spark burning out quickly.  Looks a lot nicer.

Lemme know thoughts/feedback, I can rework several more particles or teach others if need be