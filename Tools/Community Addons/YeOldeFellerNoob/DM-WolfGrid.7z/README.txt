NOVAK Software Presents...

DM-WolfGrid
_-_-_-_-_-_-_-_-_-_-

NOTE: If you had installed the original DM-WolfGrid, you should get a new copy of the build, unless you have a backup build where you can replace stuff in case things go wrong.

This version uses its own texture packages, unlike the original which used the e1l1. I give the deepest apology to EduCatOR, as I tried arguing with the person that actually ran the servers
without knowing anything about how the servers work and that he ran the servers, at least I think he runs the servers...

This adds two new rooms and adds more stuff than the original, so there is no reason to keep playing the original unless its for archival purposes. Anywho, enjoy!

