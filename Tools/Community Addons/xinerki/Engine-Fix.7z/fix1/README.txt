to use with my widescreen patch:
fixed the muzzle flash position, it still doesnt adhere to fov but hey it works