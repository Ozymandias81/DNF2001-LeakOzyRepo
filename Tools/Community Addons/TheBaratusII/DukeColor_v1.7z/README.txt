DNF 2001 : DukeColor Pack

This will readd Duke Nukem back to the player select menu, but now with various colors for the tanktop and pants!

I've also included a few face textures as well, credits to BabblingBrook, Po98 and meowth for the face textures.

~ THEBaratusII