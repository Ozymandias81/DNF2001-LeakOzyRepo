THE Aforementioned Patch v1.1 for Duke Nukem Forever 2001!
by THEBaratusII
I also give credits to those fixing this game.

Changelogs

v1.0
- Included dnf01_mp_110521.zip
- Included a tweaked DukeForever.ini with adjustments that improves the game

v1.1
- Included dnf01_mp_120521.zip
- Included Engine.dll fix (fixes unstable framerates)
- Included DukeColors v1 Skin Pack (Change Duke Nukem's Tanktop and Pants + Faces)
- Added in a Renderers folder for swapping between the Direct3D8 & DXVK Vulkan methods.
