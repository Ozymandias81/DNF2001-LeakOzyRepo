I released yesterday some edits to the default skin in modeling section but this appears to be more of a texture thing, the default duke model's hands are uvmapped on to the chest so I had to get more creative, added add an extra strap in the mid section and made the shoulder strap looked more ripped and damaged so that the hands can at leak look half normal.

Place multiplayer.mds into /System (backup Original)
Place DukeFix.Dtx into /Textures