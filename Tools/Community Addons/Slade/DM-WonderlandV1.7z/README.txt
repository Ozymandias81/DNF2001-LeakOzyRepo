DM-WonderlandV1 , ported from Rune
cute little map, might be good for up to 4 players